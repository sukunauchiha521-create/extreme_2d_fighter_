# Extreme 2D Fighter (React + Canvas)

Controls:
- P1 — Move: A/D • Jump: W • Block: S • Dash: Shift • Light: J • Heavy: K • Special: L
- P2 — Move: ←/→ • Jump: ↑ • Block: ↓ • Dash: Shift • Light: , • Heavy: . • Special: /

## Run
```bash
npm install
npm run dev
```
Open the URL Vite prints in the terminal.

## Sprites
Add/replace PNG strips in:
- `public/sprites/p1/{animation}.png`
- `public/sprites/p2/{animation}.png`

Each sheet must be a single row strip with these frame counts:
- idle(6), walk(8), jump(4), dash(4), block(2), light(5), heavy(6), special(8), hurt(3), ko(2)

Default frame size used by the procedural generator: 80x120.
