import React, { useEffect, useMemo, useRef, useState } from "react";

const WIDTH = 960;
const HEIGHT = 540;
const GROUND_Y = HEIGHT - 90;
const GRAVITY = 2200; // px/s^2
const FRICTION_GROUND = 0.88;
const AIR_DRAG = 0.995;

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const rand = (a, b) => a + Math.random() * (b - a);

// Key maps
const P1_KEYS = { left: "a", right: "d", up: "w", down: "s", dash: "shift", lp: "j", hp: "k", sp: "l" };
const P2_KEYS = { left: "arrowleft", right: "arrowright", up: "arrowup", down: "arrowdown", dash: "shift", lp: ",", hp: ".", sp: "/" };

// Attack data
const MOVES = {
  idle: {},
  walk: {},
  jump: {},
  dash: { startup: 40, active: 120, recovery: 140 },
  block: { startup: 0, active: 999, recovery: 120 },
  light:  { damage: 6,  hitstun: 180, blockstun: 110, startup: 90,  active: 90,  recovery: 200, kb: { x: 220, y: -80 },  prio: 1 },
  heavy:  { damage: 14, hitstun: 260, blockstun: 140, startup: 160, active: 120, recovery: 300, kb: { x: 380, y: -260 }, prio: 2 },
  special:{ damage: 24, hitstun: 360, blockstun: 200, startup: 180, active: 160, recovery: 360, kb: { x: 520, y: -360 }, prio: 3, cost: 40 },
};

// Animation config
const ANIM = {
  idle:    { frames: 6,  fps: 8,  loop: true },
  walk:    { frames: 8,  fps: 10, loop: true },
  jump:    { frames: 4,  fps: 8,  loop: false, next: "idle" },
  dash:    { frames: 4,  fps: 14, loop: false, next: "idle" },
  block:   { frames: 2,  fps: 6,  loop: true },
  light:   { frames: 5,  fps: 12, loop: false, next: "idle" },
  heavy:   { frames: 6,  fps: 11, loop: false, next: "idle" },
  special: { frames: 8,  fps: 12, loop: false, next: "idle" },
  hurt:    { frames: 3,  fps: 10, loop: false, next: "idle" },
  ko:      { frames: 2,  fps: 3,  loop: false, next: "idle" },
};

function useKeys() {
  const [keys, setKeys] = useState({});
  useEffect(() => {
    const d = (e) => setKeys((k) => ({ ...k, [e.key.toLowerCase()]: true }));
    const u = (e) => setKeys((k) => ({ ...k, [e.key.toLowerCase()]: false }));
    window.addEventListener("keydown", d);
    window.addEventListener("keyup", u);
    return () => { window.removeEventListener("keydown", d); window.removeEventListener("keyup", u); };
  }, []);
  return keys;
}

function drawRoundedRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function healthBar(ctx, x, y, w, h, val, hue) {
  ctx.save();
  ctx.globalAlpha = 0.9;
  ctx.fillStyle = `hsl(${hue}, 20%, 15%)`;
  drawRoundedRect(ctx, x, y, w, h, 10);
  ctx.fill();
  const ww = Math.max(0, (w - 4) * (val / 100));
  ctx.fillStyle = `hsl(${hue}, 85%, 55%)`;
  drawRoundedRect(ctx, x + 2, y + 2, ww, h - 4, 8);
  ctx.fill();
  ctx.restore();
}

function meterBar(ctx, x, y, w, h, val, hue) {
  ctx.save();
  ctx.globalAlpha = 0.85;
  ctx.fillStyle = `hsl(${hue}, 20%, 12%)`;
  drawRoundedRect(ctx, x, y, w, h, 10);
  ctx.fill();
  const ww = Math.max(0, (w - 4) * (val / 100));
  ctx.fillStyle = `hsl(${hue}, 75%, 45%)`;
  drawRoundedRect(ctx, x + 2, y + 2, ww, h - 4, 8);
  ctx.fill();
  ctx.restore();
}

// === Procedural Sprite Sheet Generator =====================================
function makeCanvas(w, h) {
  const c = document.createElement("canvas");
  c.width = w; c.height = h; return c;
}

function drawHumanoidFrame(ctx, t, animName, palette) {
  ctx.clearRect(0,0,ctx.canvas.width, ctx.canvas.height);
  ctx.save();
  ctx.translate(40, 96); 
  const sway = Math.sin(t * Math.PI * 2) * 4;
  const lift = animName === 'jump' ? -20 * Math.min(1, t*2) : 0;
  ctx.translate(0, lift);

  ctx.globalAlpha = 0.25;
  ctx.fillStyle = "black";
  ctx.beginPath();
  ctx.ellipse(0, 24, 24, 8, 0, 0, Math.PI*2);
  ctx.fill();
  ctx.globalAlpha = 1;

  ctx.fillStyle = palette.base;
  ctx.strokeStyle = palette.accent;
  ctx.lineWidth = 6;

  ctx.save();
  ctx.translate(0, -30 + (animName==='hurt'? 6:0));
  ctx.rotate((animName==='dash'? -0.2: 0) + (animName==='heavy'? -0.15: 0) + (animName==='light'? 0.1:0));
  ctx.beginPath();
  ctx.roundRect(-12, -26, 24, 50, 8);
  ctx.fill();
  ctx.stroke();
  ctx.restore();

  ctx.save();
  ctx.translate(0, -64 + (animName==='hurt'? 4:0));
  ctx.beginPath();
  ctx.arc(0, 0, 14, 0, Math.PI*2);
  ctx.fillStyle = palette.accent;
  ctx.fill();
  ctx.lineWidth = 4;
  ctx.strokeStyle = palette.base;
  ctx.stroke();
  ctx.restore();

  function limb(ax, ay, bx, by) {
    ctx.beginPath();
    ctx.moveTo(ax, ay);
    ctx.lineTo(bx, by);
    ctx.stroke();
  }

  ctx.strokeStyle = palette.accent;
  ctx.lineWidth = 6;

  const walk = animName==='walk' ? sway*2 : 0;
  const attack = (animName==='light'||animName==='heavy'||animName==='special') ? 1 : 0;

  limb(-6, 10, -12 - walk, 28);
  limb( 6, 10,  12 + walk, 28);

  const reach = attack ? (animName==='light'? 24 : animName==='heavy'? 34 : 42) : 16;
  limb(-10, -30, -10 - reach + (attack?-sway*2:0), -30 + (attack?-6:6));
  limb( 10, -30,  10 + reach + (attack? sway*2:0), -30 + (attack?-2:2));

  if (animName==='special' || animName==='heavy') {
    ctx.save();
    ctx.globalAlpha = 0.35 + (animName==='special'?0.25:0);
    ctx.fillStyle = palette.glow;
    ctx.beginPath();
    ctx.ellipse( attack? (22 + sway*2) : 16, -34, 20, 8, 0, 0, Math.PI*2);
    ctx.fill();
    ctx.restore();
  }

  if (animName==='block') {
    ctx.save();
    ctx.globalAlpha = 0.25;
    ctx.strokeStyle = palette.glow;
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(10, -36, 26, -0.5, 1.1);
    ctx.stroke();
    ctx.restore();
  }

  if (animName==='ko') {
    ctx.save();
    ctx.translate(0, -70);
    ctx.rotate(t * Math.PI * 2);
    ctx.fillStyle = palette.glow;
    ctx.beginPath();
    for (let i=0;i<5;i++){ const a = i*2*Math.PI/5; ctx.lineTo(Math.cos(a)*8, Math.sin(a)*8); }
    ctx.fill();
    ctx.restore();
  }

  ctx.restore();
}

function generateSpriteSheet(animName, frames, palette) {
  const fw = 80, fh = 120;
  const sheet = makeCanvas(fw * frames, fh);
  const sctx = sheet.getContext("2d");
  for (let i=0;i<frames;i++) {
    const t = i / frames;
    sctx.save();
    sctx.translate(fw * i + 40, 60);
    const cell = makeCanvas(fw, fh);
    const cctx = cell.getContext("2d");
    drawHumanoidFrame(cctx, t, animName, palette);
    sctx.drawImage(cell, fw*i, 0);
    sctx.restore();
  }
  return sheet;
}

function buildSpritePackProcedural(hue) {
  const palette = {
    base: `hsl(${hue}, 45%, 52%)`,
    accent: `hsl(${hue}, 80%, 70%)`,
    glow: `hsla(${hue}, 95%, 65%, 0.8)`,
  };
  const pack = {};
  for (const name of Object.keys(ANIM)) {
    const frames = ANIM[name].frames;
    pack[name] = generateSpriteSheet(name, frames, palette);
  }
  return pack;
}

// ====== External sprite loader with fallback ======
function loadImage(url) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = url;
  });
}

async function buildSpritePackExternal(basePath) {
  const pack = {};
  for (const name of Object.keys(ANIM)) {
    const url = `${basePath}/${name}.png`;
    pack[name] = await loadImage(url);
  }
  return pack;
}

function mergePacks(primary, fallback) {
  const out = {};
  for (const key of Object.keys(ANIM)) {
    out[key] = primary[key] || fallback[key];
  }
  return out;
}

// === Fighters ===============================================================
function makeFighter(x, face, name, hue) {
  return {
    name,
    x,
    y: GROUND_Y,
    vx: 0, vy: 0,
    w: 58, h: 110,
    face,
    state: "idle",
    stateTime: 0,
    canAct: true,
    hp: 100,
    stamina: 100,
    super: 0,
    combo: 0,
    comboTimer: 0,
    hitstop: 0,
    invuln: 0,
    juggle: 0,
    blocking: false,
    attack: null,
    hurt: 0,
    hue,
    anim: { name: "idle", frame: 0, time: 0 },
    sprites: null,
    ai: null,
  };
}

function getAttackBox(p) {
  if (!p.attack) return null;
  const t = p.attack;
  const move = MOVES[t.type];
  const facing = p.face;
  const originX = p.x + (facing === 1 ? p.w : -p.w);
  const width = t.type === "heavy" ? 70 : t.type === "special" ? 90 : 58;
  const height = t.type === "special" ? 80 : 60;
  const y = p.y - p.h + (t.type === "heavy" ? 10 : 25);
  const x = facing === 1 ? originX : originX - width;
  return { x, y, w: width, h: height, prio: move.prio };
}

function aabb(a, b) { return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y; }

function makeAI() {
  return {
    think(cd, self, foe, keys, dt) {
      for (const k of Object.values(P2_KEYS)) keys[k] = false;
      const dx = foe.x - self.x;
      const dist = Math.abs(dx);
      const close = dist < 160;
      const veryClose = dist < 110;
      self.face = dx > 0 ? 1 : -1;
      if (Math.random() < 0.01) keys[P2_KEYS.dash] = true;
      if (dist > 120) keys[dx > 0 ? P2_KEYS.right : P2_KEYS.left] = true; else if (!veryClose && Math.random() < 0.3) keys[dx < 0 ? P2_KEYS.right : P2_KEYS.left] = true;
      if (Math.random() < 0.01 && self.y >= GROUND_Y) keys[P2_KEYS.up] = true;
      if (foe.attack && Math.random() < 0.55) keys[P2_KEYS.down] = true;
      if (close && Math.random() < 0.06) keys[P2_KEYS.lp] = true;
      if (veryClose && Math.random() < 0.045) keys[P2_KEYS.hp] = true;
      if (self.super >= 50 && veryClose && Math.random() < 0.03) keys[P2_KEYS.sp] = true;
    },
  };
}

export default function Extreme2DFighter() {
  const canvasRef = useRef(null);
  const [mode, setMode] = useState("1P vs CPU");
  const [paused, setPaused] = useState(false);
  const [round, setRound] = useState(1);
  const [message, setMessage] = useState("Fight!");
  const [slowmo, setSlowmo] = useState(1);
  const [ready, setReady] = useState(false);

  const keys = useKeys();
  const stateRef = useRef(null);
  const ui = useMemo(() => ({ bgHueA: 210, bgHueB: 260 }), []);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const p1 = makeFighter(260, 1, "Player 1", 200);
      const p2 = makeFighter(WIDTH - 260, -1, "Player 2", 20);
      if (mode === "1P vs CPU") p2.ai = makeAI();

      // Build procedural packs first
      const proc1 = buildSpritePackProcedural(p1.hue);
      const proc2 = buildSpritePackProcedural(p2.hue);

      // Try external images (if missing, entries will be null)
      const ext1 = await buildSpritePackExternal("/sprites/p1");
      const ext2 = await buildSpritePackExternal("/sprites/p2");

      // Merge external over procedural
      p1.sprites = mergePacks(ext1, proc1);
      p2.sprites = mergePacks(ext2, proc2);

      if (!mounted) return;
      stateRef.current = {
        fighters: [p1, p2],
        particles: [],
        time: 0,
        lastTs: 0,
        winner: null,
        cameraShake: 0,
      };
      setReady(true);
      setMessage("Fight!");
    })();

    return () => { mounted = false; };
  }, [mode, round]);

  function pushParticle(st, x, y, vx, vy, life, size, hue) {
    st.particles.push({ x, y, vx, vy, life, max: life, size, hue });
  }

  function spawnHitFX(st, x, y, hue) {
    for (let i = 0; i < 10; i++) pushParticle(st, x, y, rand(-180, 180), rand(-320, -40), rand(0.2, 0.5), rand(3, 6), hue);
  }

  function setAnim(p, name) { p.anim.name = name; p.anim.frame = 0; p.anim.time = 0; }

  function updateAnim(p, dt) {
    const cfg = ANIM[p.anim.name];
    if (!cfg) return;
    p.anim.time += dt;
    if (p.anim.time >= 1 / cfg.fps) {
      p.anim.time = 0;
      p.anim.frame++;
      if (p.anim.frame >= cfg.frames) {
        if (cfg.loop) p.anim.frame = 0; else if (cfg.next) setAnim(p, cfg.next); else p.anim.frame = cfg.frames - 1;
      }
    }
  }

  function handleMovement(st, p, inputs, dt) {
    const onGround = p.y >= GROUND_Y;
    const speed = 420;
    const dashBoost = 720;

    const foe = st.fighters[0] === p ? st.fighters[1] : st.fighters[0];
    p.face = foe.x > p.x ? 1 : -1;

    p.blocking = inputs.down && onGround && p.canAct && p.state !== "dash";

    if (p.canAct && !p.blocking) {
      if (inputs.left) p.vx = lerp(p.vx, -speed, onGround ? 0.7 : 0.35);
      if (inputs.right) p.vx = lerp(p.vx, speed, onGround ? 0.7 : 0.35);
      if (!inputs.left && !inputs.right) p.vx *= onGround ? FRICTION_GROUND : AIR_DRAG;
      if (inputs.up && onGround) { p.vy = -880; p.state = "jump"; setAnim(p, "jump"); }
      if (inputs.dash && onGround && p.stamina >= 12 && p.state !== "dash") {
        p.stamina -= 12; p.vx = p.face * dashBoost; p.state = "dash"; p.stateTime = 0; setAnim(p, "dash");
      }
    } else { p.vx *= onGround ? FRICTION_GROUND : AIR_DRAG; }

    p.vy += GRAVITY * dt;

    p.x += p.vx * dt;
    p.y += p.vy * dt;

    if (p.y > GROUND_Y) { p.y = GROUND_Y; p.vy = 0; }
    p.x = clamp(p.x, 40, WIDTH - 40);

    p.stateTime += dt * 1000;

    if (p.state === "dash") {
      if (p.stateTime > MOVES.dash.startup + MOVES.dash.active) { p.state = "idle"; p.canAct = true; setAnim(p, "idle"); }
    }

    if (p.blocking) setAnim(p, "block");
    else if (onGround && Math.abs(p.vx) > 60 && p.canAct) setAnim(p, "walk");
    else if (onGround && p.canAct && p.state !== "dash" && !p.attack) setAnim(p, "idle");

    if (onGround && !p.blocking) p.stamina = clamp(p.stamina + 18 * dt, 0, 100);
    p.super = clamp(p.super + 5 * dt, 0, 100);

    if (p.comboTimer > 0) p.comboTimer -= dt; else p.combo = 0;
    if (p.hitstop > 0) p.hitstop -= dt; if (p.invuln > 0) p.invuln -= dt; if (p.hurt > 0) p.hurt -= dt;

    updateAnim(p, dt);
  }

  function startAttack(p, type) {
    const mv = MOVES[type];
    if (!mv) return; if (!p.canAct || p.blocking) return; if (type === "special" && p.super < (mv.cost || 0)) return;
    p.attack = { type, t: 0 }; p.state = type; p.stateTime = 0; p.canAct = false; setAnim(p, type);
    if (type === "special") p.super = clamp(p.super - (mv.cost || 0), 0, 100);
  }

  function updateAttack(st, p, foe, dt) {
    if (!p.attack) return;
    const at = p.attack; const mv = MOVES[at.type]; at.t += dt * 1000;
    const activeStart = mv.startup; const activeEnd = mv.startup + mv.active;
    const recovering = at.t > activeEnd;

    if (at.t >= activeStart && at.t <= activeEnd) {
      const hb = getAttackBox(p); const hurtbox = { x: foe.x - foe.w / 2, y: foe.y - foe.h, w: foe.w, h: foe.h };
      if (hb && aabb(hb, hurtbox)) {
        const blocked = foe.blocking && foe.y >= GROUND_Y && foe.invuln <= 0; const scale = 1 - foe.juggle * 0.18;
        const dmg = Math.max(1, Math.round(mv.damage * (blocked ? 0.4 : 1) * Math.max(0.4, scale)));
        if (foe.invuln <= 0) {
          foe.hp = clamp(foe.hp - dmg, 0, 100); foe.hurt = 0.12; setAnim(foe, foe.hp<=0 ? "ko" : "hurt");
          spawnHitFX(st, foe.x, foe.y - foe.h + 40, p.hue);
          st.cameraShake = Math.min(16, st.cameraShake + (mv.prio * 3 + 4));
          const kb = mv.kb; foe.vx = p.face * kb.x * (blocked ? 0.4 : 1) * Math.max(0.4, scale); foe.vy = kb.y * (blocked ? 0.3 : 1) * Math.max(0.4, scale);
          foe.juggle = Math.min(3, foe.juggle + 1); foe.invuln = blocked ? 0.05 : 0.08;
          const stun = (blocked ? mv.blockstun : mv.hitstun) * Math.max(0.5, scale);
          foe.canAct = false; setTimeout(() => (foe.canAct = true), stun);
          p.combo += 1; p.comboTimer = 1.2; p.super = clamp(p.super + (blocked ? 2 : 6), 0, 100);
          if (mv.prio >= 2) { p.hitstop = 0.04; foe.hitstop = 0.08; }
          if (mv.prio >= 3) { setSlowmo(0.5); setTimeout(() => setSlowmo(1), 160); }
          if (at.type === "light") at.t = activeEnd + 1;
        }
      }
    }

    if (recovering) {
      if (at.t > mv.startup + mv.active + mv.recovery) { p.attack = null; p.canAct = true; p.state = "idle"; setAnim(p, "idle"); p.stateTime = 0; }
    }
  }

  function step(st, dt) {
    const [p1, p2] = st.fighters;

    const in1 = { left: !!keys[P1_KEYS.left], right: !!keys[P1_KEYS.right], up: !!keys[P1_KEYS.up], down: !!keys[P1_KEYS.down], dash: !!keys[P1_KEYS.dash], lp: !!keys[P1_KEYS.lp], hp: !!keys[P1_KEYS.hp], sp: !!keys[P1_KEYS.sp] };
    const aiKeys = { ...keys };
    if (p2.ai) p2.ai.think(st, p2, p1, aiKeys, dt);
    const in2 = p2.ai ? {
      left: !!aiKeys[P2_KEYS.left], right: !!aiKeys[P2_KEYS.right], up: !!aiKeys[P2_KEYS.up], down: !!aiKeys[P2_KEYS.down], dash: !!aiKeys[P2_KEYS.dash], lp: !!aiKeys[P2_KEYS.lp], hp: !!aiKeys[P2_KEYS.hp], sp: !!aiKeys[P2_KEYS.sp]
    } : { left: !!keys[P2_KEYS.left], right: !!keys[P2_KEYS.right], up: !!keys[P2_KEYS.up], down: !!keys[P2_KEYS.down], dash: !!keys[P2_KEYS.dash], lp: !!keys[P2_KEYS.lp], hp: !!keys[P2_KEYS.hp], sp: !!keys[P2_KEYS.sp] };

    if (in1.lp) startAttack(p1, "light");
    if (in1.hp) startAttack(p1, "heavy");
    if (in1.sp) startAttack(p1, "special");
    if (in2.lp) startAttack(p2, "light");
    if (in2.hp) startAttack(p2, "heavy");
    if (in2.sp) startAttack(p2, "special");

    handleMovement(st, p1, in1, dt);
    handleMovement(st, p2, in2, dt);

    updateAttack(st, p1, p2, dt);
    updateAttack(st, p2, p1, dt);

    if (p1.y >= GROUND_Y) p1.juggle = Math.max(0, p1.juggle - dt * 2);
    if (p2.y >= GROUND_Y) p2.juggle = Math.max(0, p2.juggle - dt * 2);

    for (let i = st.particles.length - 1; i >= 0; i--) {
      const p = st.particles[i]; p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += GRAVITY * 0.2 * dt; if (p.life <= 0) st.particles.splice(i, 1);
    }

    if (!st.winner && (p1.hp <= 0 || p2.hp <= 0)) {
      st.winner = p1.hp <= 0 ? p2 : p1; setMessage(`${st.winner.name} Wins!`); setSlowmo(0.4); setTimeout(() => setSlowmo(1), 400); setTimeout(() => setRound((r) => r + 1), 1800);
    }

    st.time += dt;
  }

  function render(st, ctx) {
    ctx.save();
    const shake = st.cameraShake; st.cameraShake = Math.max(0, st.cameraShake - 1.2); ctx.translate(rand(-shake, shake), rand(-shake, shake));
    const g = ctx.createLinearGradient(0, 0, 0, HEIGHT); g.addColorStop(0, `hsl(${ui.bgHueA}, 40%, 12%)`); g.addColorStop(1, `hsl(${ui.bgHueB}, 40%, 6%)`); ctx.fillStyle = g; ctx.fillRect(0, 0, WIDTH, HEIGHT);
    ctx.fillStyle = "rgba(255,255,255,0.06)"; ctx.fillRect(0, GROUND_Y + 1, WIDTH, HEIGHT - GROUND_Y);

    for (const p of st.fighters) {
      const y = p.y - p.h;
      ctx.globalAlpha = 0.25; ctx.beginPath(); ctx.ellipse(p.x, GROUND_Y + 6, 38, 10, 0, 0, Math.PI * 2); ctx.fillStyle = "black"; ctx.fill(); ctx.globalAlpha = 1;

      const sheet = p.sprites?.[p.anim.name];
      const frames = ANIM[p.anim.name]?.frames || 1;
      if (sheet) {
        const fw = sheet.width / frames; const fh = sheet.height;
        ctx.save();
        ctx.translate(p.x, y);
        if (p.face === -1) { ctx.scale(-1, 1); }
        ctx.drawImage(sheet, fw * (p.anim.frame % frames), 0, fw, fh, -fw/2, 0, fw, fh);
        ctx.restore();
      }

      if (p.attack) {
        const hb = getAttackBox(p);
        if (hb) { ctx.globalAlpha = 0.14; ctx.fillStyle = `hsl(${p.hue}, 90%, 60%)`; drawRoundedRect(ctx, hb.x, hb.y, hb.w, hb.h, 6); ctx.fill(); ctx.globalAlpha = 1; }
      }
    }

    for (const fx of st.particles) { ctx.globalAlpha = Math.max(0, fx.life / fx.max); ctx.fillStyle = `hsl(${fx.hue}, 85%, 65%)`; drawRoundedRect(ctx, fx.x, fx.y, fx.size, fx.size, 2); ctx.fill(); ctx.globalAlpha = 1; }

    const [p1, p2] = st.fighters;
    healthBar(ctx, 20, 18, 360, 24, p1.hp, p1.hue); healthBar(ctx, WIDTH - 380, 18, 360, 24, p2.hp, p2.hue);
    meterBar(ctx, 20, 50, 280, 14, p1.stamina, p1.hue); meterBar(ctx, 20, 68, 320, 12, p1.super, p1.hue);
    meterBar(ctx, WIDTH - 340, 50, 280, 14, p2.stamina, p2.hue); meterBar(ctx, WIDTH - 360, 68, 320, 12, p2.super, p2.hue);

    ctx.font = "700 28px ui-sans-serif,system-ui"; ctx.textAlign = "left"; ctx.fillStyle = "rgba(255,255,255,0.9)";
    if (p1.combo > 1 && p1.comboTimer > 0) ctx.fillText(`${p1.combo} HIT`, 24, 120);
    ctx.textAlign = "right"; if (p2.combo > 1 && p2.comboTimer > 0) ctx.fillText(`${p2.combo} HIT`, WIDTH - 24, 120);

    ctx.restore();
  }

  useEffect(() => {
    if (!ready) return; const canvas = canvasRef.current; const ctx = canvas.getContext("2d"); let anim;
    function loop(ts) {
      const st = stateRef.current; if (!st) return; if (!st.lastTs) st.lastTs = ts; let dt = (ts - st.lastTs) / 1000; st.lastTs = ts; dt = Math.min(dt, 0.033);
      if (!paused) { const eff = dt * slowmo; if (st.fighters.some((p) => p.hitstop > 0)) step(st, eff * 0.15); else step(st, eff); }
      render(st, ctx); anim = requestAnimationFrame(loop);
    }
    anim = requestAnimationFrame(loop); return () => cancelAnimationFrame(anim);
  }, [paused, slowmo, ready]);

  return (
    <div className="w-full h-full min-h-[640px] bg-neutral-900 text-white flex flex-col items-center justify-start gap-3 p-4 select-none">
      <div className="w-full max-w-[1100px] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-extrabold tracking-tight">Extreme 2D Fighter</h1>
          <span className="text-xs opacity-70">v2.0 • animated sprites + PNG fallback</span>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-sm opacity-80">Mode</label>
          <select className="bg-neutral-800 px-3 py-2 rounded-2xl text-sm outline-none" value={mode} onChange={(e) => setMode(e.target.value)} disabled={ready && stateRef.current?.time > 0}>
            <option>1P vs CPU</option>
            <option>1P vs 2P</option>
          </select>
          <button className="px-4 py-2 rounded-2xl bg-neutral-800 hover:bg-neutral-700 transition shadow" onClick={() => setPaused((p) => !p)}>{paused ? "Resume" : "Pause"}</button>
          <button className="px-4 py-2 rounded-2xl bg-neutral-800 hover:bg-neutral-700 transition shadow" onClick={() => setRound((r) => r + 1)}>Reset Round</button>
        </div>
      </div>

      <div className="relative w-full max-w-[1100px] rounded-2xl overflow-hidden shadow-2xl">
        <canvas ref={canvasRef} width={WIDTH} height={HEIGHT} className="w-full h-auto block bg-black" />
        <div className="pointer-events-none absolute inset-0 flex items-start justify-center p-3">
          <div className="mt-2 text-center">
            <div className="text-white/80 text-sm">Round {round}</div>
            <div className="text-3xl font-black drop-shadow-[0_2px_8px_rgba(0,0,0,0.5)]">{message}</div>
          </div>
        </div>

        <div className="absolute bottom-2 left-2 right-2 grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] text-white/80">
          <div className="bg-black/30 backdrop-blur rounded-2xl px-3 py-2">
            <div className="font-bold text-white/90 text-xs mb-1">P1 Controls</div>
            <div>Move: A/D • Jump: W • Block: S • Dash: Shift</div>
            <div>Light: J • Heavy: K • Special: L</div>
          </div>
          <div className="bg-black/30 backdrop-blur rounded-2xl px-3 py-2">
            <div className="font-bold text-white/90 text-xs mb-1">P2 Controls {mode === "1P vs CPU" ? "(CPU)" : "(2P)"}</div>
            <div>Move: ←/→ • Jump: ↑ • Block: ↓ • Dash: Shift</div>
            <div>Light: , • Heavy: . • Special: /</div>
          </div>
        </div>
      </div>

      <div className="max-w-[1100px] w-full text-xs leading-relaxed text-white/70">
        <p>
          External sprite support is enabled. Put sprite strips into <code>public/sprites/p1</code> and <code>public/sprites/p2</code> with these names: idle, walk, jump, dash, block, light, heavy, special, hurt, ko.
          Missing files will fall back to the built-in procedural sprites.
        </p>
      </div>
    </div>
  );
}
